import { type NextRequest, NextResponse } from "next/server"

const HUGGING_FACE_API_KEY = "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"

export async function POST(req: NextRequest) {
  try {
    const {
      prompt,
      negative_prompt = "blurry, distorted, low quality, ugly, bad anatomy",
      style = "realistic",
      guidance_scale = 7.5,
      width = 512,
      height = 512,
    } = await req.json()

    if (!prompt) {
      return NextResponse.json({ error: "No prompt provided" }, { status: 400 })
    }

    // Enhance prompt based on style
    let enhancedPrompt = prompt
    if (style === "anime") {
      enhancedPrompt = `${prompt}, anime style, anime art, detailed anime drawing`
    } else if (style === "digital-art") {
      enhancedPrompt = `${prompt}, digital art, digital painting, detailed digital illustration`
    } else if (style === "oil-painting") {
      enhancedPrompt = `${prompt}, oil painting, detailed brushstrokes, canvas texture`
    } else if (style === "watercolor") {
      enhancedPrompt = `${prompt}, watercolor painting, soft colors, watercolor texture`
    } else if (style === "pixel-art") {
      enhancedPrompt = `${prompt}, pixel art, 8-bit style, pixelated`
    } else if (style === "sketch") {
      enhancedPrompt = `${prompt}, pencil sketch, hand-drawn, detailed sketch`
    } else if (style === "comic") {
      enhancedPrompt = `${prompt}, comic book style, comic art, bold lines`
    } else if (style === "3d-render") {
      enhancedPrompt = `${prompt}, 3D render, 3D modeling, realistic 3D`
    } else {
      // Default to realistic
      enhancedPrompt = `${prompt}, realistic, detailed, high quality photograph`
    }

    // Prepare the request payload
    const payload = {
      inputs: enhancedPrompt,
      parameters: {
        negative_prompt: negative_prompt,
        guidance_scale: guidance_scale,
      },
    }

    // Make the API request
    const response = await fetch(
      "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${HUGGING_FACE_API_KEY}`,
        },
        body: JSON.stringify(payload),
      },
    )

    if (!response.ok) {
      const errorText = await response.text()
      console.error("Hugging Face API error response:", errorText)
      throw new Error(`Hugging Face API error: ${errorText}`)
    }

    // The response is a binary image
    const imageBuffer = await response.arrayBuffer()
    const base64Image = Buffer.from(imageBuffer).toString("base64")
    const imageUrl = `data:image/jpeg;base64,${base64Image}`

    // Generate a description using the prompt
    const description = `Here's the image I generated based on your prompt: "${prompt}"`

    return NextResponse.json({
      imageUrl,
      description,
    })
  } catch (error) {
    console.error("Image Generation Error:", error)
    return NextResponse.json(
      {
        error: "Failed to generate image",
        description: "I couldn't generate the image you requested. Please try a different prompt.",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
