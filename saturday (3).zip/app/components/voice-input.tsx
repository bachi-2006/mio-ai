"use client"

import { useState, useEffect, useRef } from "react"
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { AnimatedButton } from "@/components/ui/animated-button"
import { AnimatedLoader } from "@/components/ui/animated-loader"
import { useTheme } from "@/lib/theme-context"
import { motion } from "framer-motion"

interface VoiceInputProps {
  onSpeechResult: (text: string) => void
  onSpeakToggle?: (isSpeaking: boolean) => void
  disabled?: boolean
}

export function VoiceInput({ onSpeechResult, onSpeakToggle, disabled = false }: VoiceInputProps) {
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [isRecognitionSupported, setIsRecognitionSupported] = useState(true)
  const [isSpeechSynthesisSupported, setIsSpeechSynthesisSupported] = useState(true)
  const recognitionRef = useRef<any>(null)
  const synthesisRef = useRef<SpeechSynthesis | null>(null)
  const { theme } = useTheme()

  // Initialize speech recognition and synthesis
  useEffect(() => {
    // Check if SpeechRecognition is supported
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = "en-US"

        recognitionRef.current.onresult = (event: any) => {
          const result = event.results[event.results.length - 1]
          const transcript = result[0].transcript
          setTranscript(transcript)

          // If result is final, send it to parent
          if (result.isFinal) {
            onSpeechResult(transcript)
            stopListening()
          }
        }

        recognitionRef.current.onerror = (event: any) => {
          console.error("Speech recognition error", event.error)
          stopListening()
        }

        recognitionRef.current.onend = () => {
          setIsListening(false)
        }
      } else {
        setIsRecognitionSupported(false)
      }

      // Check if Speech Synthesis is supported
      if ("speechSynthesis" in window) {
        synthesisRef.current = window.speechSynthesis
      } else {
        setIsSpeechSynthesisSupported(false)
      }
    }

    return () => {
      stopListening()
      stopSpeaking()
    }
  }, [onSpeechResult])

  const toggleListening = () => {
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start()
        setIsListening(true)
        setTranscript("")
      } catch (error) {
        console.error("Error starting speech recognition:", error)
      }
    }
  }

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      try {
        recognitionRef.current.stop()
        setIsListening(false)
      } catch (error) {
        console.error("Error stopping speech recognition:", error)
      }
    }
  }

  const toggleSpeaking = () => {
    if (isSpeaking) {
      stopSpeaking()
    } else {
      setIsSpeaking(true)
      if (onSpeakToggle) onSpeakToggle(true)
    }
  }

  const stopSpeaking = () => {
    if (synthesisRef.current) {
      synthesisRef.current.cancel()
      setIsSpeaking(false)
      if (onSpeakToggle) onSpeakToggle(false)
    }
  }

  if (!isRecognitionSupported) {
    return (
      <Button
        variant="ghost"
        size="icon"
        disabled={true}
        title="Speech recognition is not supported in your browser"
        className="text-secondary-400"
      >
        <MicOff className="h-5 w-5" />
      </Button>
    )
  }

  return (
    <div className="flex items-center gap-2">
      {/* TTS Button */}
      {isSpeechSynthesisSupported && (
        <AnimatedButton
          variant="ghost"
          size="icon"
          animation="subtle"
          onClick={toggleSpeaking}
          disabled={disabled}
          className={`relative ${isSpeaking ? "text-primary-500" : "text-secondary-500 hover:text-secondary-700 dark:text-secondary-400 dark:hover:text-secondary-300"}`}
          title={isSpeaking ? "Stop speaking" : "Read responses aloud"}
        >
          {isSpeaking ? (
            <>
              <Volume2 className="h-5 w-5" />
              <motion.span
                className="absolute inset-0 rounded-full border-2"
                initial={{ opacity: 0.3, scale: 1 }}
                animate={{ opacity: 0, scale: 1.5 }}
                transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
                style={{ borderColor: theme.primary }}
              />
            </>
          ) : (
            <VolumeX className="h-5 w-5" />
          )}
        </AnimatedButton>
      )}

      {/* Voice Input Button */}
      <AnimatedButton
        variant="ghost"
        size="icon"
        animation="subtle"
        onClick={toggleListening}
        disabled={disabled}
        className={`relative ${isListening ? "text-primary-500" : "text-secondary-500 hover:text-secondary-700 dark:text-secondary-400 dark:hover:text-secondary-300"}`}
        title={isListening ? "Stop listening" : "Speak your message"}
      >
        {isListening ? (
          <>
            <Mic className="h-5 w-5" />
            <motion.span
              className="absolute inset-0 rounded-full border-2"
              initial={{ opacity: 0.3, scale: 1 }}
              animate={{ opacity: 0, scale: 1.5 }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
              style={{ borderColor: theme.primary }}
            />
          </>
        ) : (
          <Mic className="h-5 w-5" />
        )}
      </AnimatedButton>

      {/* Listening status */}
      {isListening && (
        <div className="absolute bottom-20 left-0 right-0 mx-auto w-4/5 max-w-lg bg-secondary-900/90 backdrop-blur-sm p-4 rounded-lg shadow-lg z-10 text-center">
          <AnimatedLoader type="wave" size="sm" className="mb-2" />
          <p className="text-white font-medium mb-1">Listening...</p>
          <p className="text-secondary-300 text-sm overflow-hidden text-ellipsis">{transcript || "Say something..."}</p>
        </div>
      )}
    </div>
  )
}
