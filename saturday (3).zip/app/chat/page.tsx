"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  MessageSquare,
  Code,
  ImageIcon,
  History,
  LogOut,
  Send,
  AlertTriangle,
  Settings,
  Menu,
  Moon,
  Sun,
  ChevronDown,
  Sparkles,
  Clock,
  CloudRain,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
// Update the import to use the provider
import { useAuth } from "@/components/providers/AuthProvider"
import { useTheme } from "@/lib/theme-context"
import { ChatMessage } from "../components/chat-message"
import { ChatHistory } from "../components/chat-history"
import { AnimatedLoader } from "@/components/ui/animated-loader"
import { AnimatedButton } from "@/components/ui/animated-button"
import { Logo } from "../components/logo"
import { VoiceInput } from "../components/voice-input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer"
import { getTelanganaWeather } from "@/lib/services/utility-service"
import { stripFormatting } from "@/lib/text-formatter"
import {
  fadeIn,
  fadeInUp,
  fadeInDown,
  staggerContainer,
  staggerItem,
  pulse,
  fadeInLeft,
  fadeInRight,
} from "@/lib/animation-variants"
import { format } from "date-fns"
import { ImageGeneration } from "../components/image-generation"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  mode?: string
  imageUrl?: string
  error?: boolean
  fallbackUsed?: boolean
}

type Mode = "chat" | "code" | "image" | "history"

export default function ChatPage() {
  // Fix the side drawer glitch by updating the state management
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [mode, setMode] = useState<Mode>("chat")
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [previousMode, setPreviousMode] = useState<Mode>("chat")
  const [imageGenerationFailed, setImageGenerationFailed] = useState(false)
  const [currentTime, setCurrentTime] = useState(format(new Date(), "h:mm a"))
  const [currentWeather, setCurrentWeather] = useState<any>(null)
  const [isLoadingWeather, setIsLoadingWeather] = useState(true)
  const [showWelcomeAnimation, setShowWelcomeAnimation] = useState(true)
  const [pageLoading, setPageLoading] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const { toast } = useToast()
  const router = useRouter()
  const { user, logout } = useAuth()
  const { theme, currentThemeName, isDarkMode, toggleDarkMode } = useTheme()
  const synthesis = useRef<SpeechSynthesis | null>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)
  const lastResponseRef = useRef<string>("")

  useEffect(() => {
    if (typeof window !== "undefined") {
      synthesis.current = window.speechSynthesis
    }

    return () => {
      if (synthesis.current) {
        synthesis.current.cancel()
      }
    }
  }, [])

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(format(new Date(), "h:mm a"))
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Get Telangana weather directly
  useEffect(() => {
    const fetchWeather = async () => {
      setIsLoadingWeather(true)
      try {
        const weather = await getTelanganaWeather()
        if (weather) {
          setCurrentWeather(weather)
        }
      } catch (error) {
        console.error("Error fetching weather:", error)
      } finally {
        setIsLoadingWeather(false)
      }
    }

    fetchWeather()
  }, [])

  // Simulate page loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setPageLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    // Greet the user when they first load the page
    if (user && synthesis.current) {
      const greeting = `Welcome, ${user.name || "User"}! How can I assist you today?`
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: greeting,
        timestamp: new Date(),
        mode: "chat",
      }

      // Add a slight delay for the welcome animation
      setTimeout(() => {
        setMessages([welcomeMessage])
        setShowWelcomeAnimation(false)
        lastResponseRef.current = greeting

        // Focus the input field
        setTimeout(() => {
          inputRef.current?.focus()
        }, 500)
      }, 2000)
    }
  }, [user])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    // Clear messages when switching modes
    if (mode !== previousMode && mode !== "history") {
      const modeMessage = `You are now in ${mode} mode. How can I help you?`
      setMessages([
        {
          id: Date.now().toString(),
          role: "assistant",
          content: modeMessage,
          timestamp: new Date(),
          mode,
        },
      ])
      setPreviousMode(mode)
      setImageGenerationFailed(false)
      lastResponseRef.current = modeMessage

      // Focus the input field after mode change
      setTimeout(() => {
        inputRef.current?.focus()
      }, 100)
    }
  }, [mode, previousMode])

  const speakResponse = (text: string) => {
    if (synthesis.current) {
      synthesis.current.cancel() // Cancel any ongoing speech

      // Strip formatting from text before speaking
      const plainText = stripFormatting(text)

      const utterance = new SpeechSynthesisUtterance(plainText)
      utterance.rate = 1.0 // Normal speed
      utterance.pitch = 1.0 // Normal pitch

      // Get available voices
      const voices = synthesis.current.getVoices()
      const preferredVoice =
        voices.find((voice) => voice.lang === "en-US" && voice.name.includes("Google")) ||
        voices.find((voice) => voice.lang === "en-US")

      if (preferredVoice) {
        utterance.voice = preferredVoice
      }

      setIsSpeaking(true)

      utterance.onend = () => {
        setIsSpeaking(false)
      }

      synthesis.current.speak(utterance)
    }
  }

  const stopSpeaking = () => {
    if (synthesis.current) {
      synthesis.current.cancel()
      setIsSpeaking(false)
    }
  }

  const generateImage = async (prompt: string) => {
    try {
      // Use the Hugging Face model
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
        }),
      })

      if (!response.ok) {
        throw new Error(`Image generation failed: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.imageUrl) {
        throw new Error("No image URL returned from model")
      }

      setImageGenerationFailed(false)
      return { ...data, fallbackUsed: false }
    } catch (error) {
      console.error("Image generation failed:", error)
      setImageGenerationFailed(true)

      // No fallback, just throw the error to be handled by the caller
      throw new Error("Image generation failed. Please try again later or with a different prompt.")
    }
  }

  const handleSubmit = useCallback(
    async (e?: React.FormEvent, voiceInput?: string) => {
      if (e) e.preventDefault()

      const userPrompt = voiceInput || input
      if (!userPrompt.trim() || isProcessing) return

      setIsProcessing(true)
      if (!voiceInput) setInput("")

      try {
        const messageId = Date.now().toString()
        const newMessage: Message = {
          id: messageId,
          role: "user",
          content: userPrompt,
          timestamp: new Date(),
          mode,
        }
        setMessages((prev) => [...prev, newMessage])

        let data: any = null

        if (mode === "code") {
          const response = await fetch("/api/generate-code", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              prompt: userPrompt,
            }),
          })

          if (!response.ok) {
            throw new Error(`Failed to process code request: ${response.statusText}`)
          }

          data = await response.json()
        } else if (mode === "image") {
          try {
            data = await generateImage(userPrompt)
          } catch (error) {
            console.error("Image generation failed:", error)
            data = {
              description:
                "I couldn't generate the image you requested. Please try again later or with a different prompt.",
              error: true,
            }
          }
        } else {
          // Regular chat mode
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              message: userPrompt,
            }),
          })

          if (!response.ok) {
            throw new Error(`Failed to process message: ${response.statusText}`)
          }

          data = await response.json()
        }

        // Safely extract content from the response
        const responseContent =
          mode === "image"
            ? data?.description || "Here's the generated image:"
            : data?.response || data?.code || "I'm not sure how to respond to that."

        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: responseContent,
          timestamp: new Date(),
          mode,
          imageUrl: mode === "image" ? data?.imageUrl : undefined,
          error: data?.error || false,
          fallbackUsed: data?.fallbackUsed || false,
        }

        setMessages((prev) => [...prev, assistantMessage])
        lastResponseRef.current = responseContent

        // If TTS is active, speak the response
        if (isSpeaking) {
          speakResponse(responseContent)
        }

        // Save to history
        const history = JSON.parse(localStorage.getItem("chatHistory") || "[]")
        history.unshift({
          id: Date.now().toString(),
          timestamp: new Date(),
          preview: userPrompt.substring(0, 50) + (userPrompt.length > 50 ? "..." : ""),
          messages: [...messages, newMessage, assistantMessage],
        })
        localStorage.setItem("chatHistory", JSON.stringify(history.slice(0, 50))) // Keep only the last 50 conversations

        // Focus the input field after response
        setTimeout(() => {
          inputRef.current?.focus()
        }, 100)
      } catch (error) {
        console.error("Error:", error)
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred",
          variant: "destructive",
        })

        // Add error message to the chat
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "assistant",
            content: `Sorry, I encountered an error: ${error instanceof Error ? error.message : "An unexpected error occurred"}. Please try again.`,
            timestamp: new Date(),
            mode,
            error: true,
          },
        ])
      } finally {
        setIsProcessing(false)
      }
    },
    [input, isProcessing, mode, messages, toast, isSpeaking],
  )

  const handleRegenerate = useCallback(
    async (messageIndex: number) => {
      if (isProcessing) return

      setIsProcessing(true)

      try {
        // Get the original user message
        const userMessage = messages[messageIndex - 1]
        if (!userMessage || userMessage.role !== "user") {
          throw new Error("Cannot find the original user message")
        }

        // Remove the assistant message that we're regenerating
        setMessages((prev) => prev.slice(0, messageIndex))

        // Re-submit the original user message
        const currentInput = userMessage.content

        let data: any = null

        if (mode === "code") {
          const response = await fetch("/api/generate-code", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              prompt: currentInput,
            }),
          })

          if (!response.ok) {
            throw new Error(`Failed to process code request: ${response.statusText}`)
          }

          data = await response.json()
        } else if (mode === "image") {
          try {
            data = await generateImage(currentInput)
          } catch (error) {
            console.error("Image generation failed:", error)
            data = {
              description:
                "I couldn't generate the image you requested. Please try again later or with a different prompt.",
              error: true,
            }
          }
        } else {
          // Regular chat mode
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              message: currentInput,
            }),
          })

          if (!response.ok) {
            throw new Error(`Failed to process message: ${response.statusText}`)
          }

          data = await response.json()
        }

        // Safely extract content from the response
        const responseContent =
          mode === "image"
            ? data?.description || "Here's the generated image:"
            : data?.response || data?.code || "I'm not sure how to respond to that."

        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: responseContent,
          timestamp: new Date(),
          mode,
          imageUrl: mode === "image" ? data?.imageUrl : undefined,
          error: data?.error || false,
          fallbackUsed: data?.fallbackUsed || false,
        }

        setMessages((prev) => [...prev, assistantMessage])
        lastResponseRef.current = responseContent

        // If TTS is active, speak the regenerated response
        if (isSpeaking) {
          speakResponse(responseContent)
        }
      } catch (error) {
        console.error("Error regenerating response:", error)
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to regenerate response",
          variant: "destructive",
        })
      } finally {
        setIsProcessing(false)
      }
    },
    [messages, isProcessing, mode, toast, isSpeaking],
  )

  const handleVoiceInput = (text: string) => {
    handleSubmit(undefined, text)
  }

  const handleSpeakToggle = (speaking: boolean) => {
    setIsSpeaking(speaking)

    // If toggling on, speak the last response
    if (speaking && lastResponseRef.current) {
      speakResponse(lastResponseRef.current)
    } else {
      stopSpeaking()
    }
  }

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
    toast({
      title: "Copied",
      description: "Message copied to clipboard",
    })
  }

  const loadHistory = (historyMessages: Message[]) => {
    setMessages(historyMessages)
    setMode("chat") // Switch back to chat mode when loading history

    // Update last response for TTS
    const lastAssistantMessage = historyMessages.filter((msg) => msg.role === "assistant").pop()

    if (lastAssistantMessage) {
      lastResponseRef.current = lastAssistantMessage.content
    }
  }

  const handleLogout = useCallback(() => {
    logout()
    router.push("/")
  }, [logout, router])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  // Auto-resize textarea as user types
  const autoResizeTextarea = () => {
    if (inputRef.current) {
      inputRef.current.style.height = "auto"
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 150)}px`
    }
  }

  // Show page loading animation
  if (pageLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-secondary-900">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <Logo size={80} animated={true} />
          <motion.h1
            className="mt-6 text-3xl font-bold text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            Mio AI
          </motion.h1>
          <motion.div className="mt-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            <AnimatedLoader type="dots" size="lg" text="Loading your experience..." />
          </motion.div>
        </motion.div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-900 to-secondary-900">
        <AnimatedLoader type="logo" size="lg" text="Loading Mio AI..." />
      </div>
    )
  }

  const Sidebar = () => (
    <motion.div
      className="h-full flex flex-col bg-white dark:bg-secondary-900 border-r border-secondary-200 dark:border-secondary-800"
      variants={fadeInLeft}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      {/* Sidebar Header */}
      <motion.div
        className="p-4 border-b border-secondary-200 dark:border-secondary-800"
        variants={fadeInDown}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.1 }}
      >
        <div className="flex items-center gap-2">
          <Logo size={32} />
          <h1 className="text-xl font-bold text-secondary-900 dark:text-white">Mio AI</h1>
        </div>
      </motion.div>

      {/* User Profile */}
      <motion.div
        className="p-4 border-b border-secondary-200 dark:border-secondary-800"
        variants={fadeInDown}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 ring-2 ring-primary-500/20">
            <AvatarImage
              src={user.picture || `https://ui-avatars.com/api/?name=${user.name || "User"}&background=random`}
            />
            <AvatarFallback>{user.name?.charAt(0) || "U"}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-secondary-900 dark:text-white truncate">{user.name || "User"}</p>
            <p className="text-xs text-secondary-500 dark:text-secondary-400 truncate">{user.email}</p>
          </div>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <ChevronDown className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56" align="end">
              <motion.div className="space-y-1" variants={staggerContainer} initial="hidden" animate="visible">
                <motion.div variants={staggerItem}>
                  <Button variant="ghost" className="w-full justify-start" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </motion.div>
                <motion.div variants={staggerItem}>
                  <Button variant="ghost" className="w-full justify-start" onClick={toggleDarkMode}>
                    {isDarkMode ? (
                      <>
                        <Sun className="h-4 w-4 mr-2" />
                        Light Mode
                      </>
                    ) : (
                      <>
                        <Moon className="h-4 w-4 mr-2" />
                        Dark Mode
                      </>
                    )}
                  </Button>
                </motion.div>
              </motion.div>
            </PopoverContent>
          </Popover>
        </div>
      </motion.div>

      {/* Time and Weather */}
      <motion.div
        className="p-4 border-b border-secondary-200 dark:border-secondary-800"
        variants={fadeInDown}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.3 }}
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center text-secondary-700 dark:text-secondary-300">
            <Clock className="h-4 w-4 mr-2" />
            <span className="text-sm">{currentTime}</span>
          </div>
        </div>

        {currentWeather && (
          <div className="flex items-center text-secondary-700 dark:text-secondary-300">
            <CloudRain className="h-4 w-4 mr-2" />
            <span className="text-sm">
              {currentWeather.location}, Telangana: {currentWeather.temperature}°C, {currentWeather.description}
            </span>
          </div>
        )}

        {isLoadingWeather && (
          <div className="flex items-center text-secondary-700 dark:text-secondary-300">
            <AnimatedLoader type="dots" size="sm" />
            <span className="text-sm ml-2">Loading Telangana weather...</span>
          </div>
        )}
      </motion.div>

      {/* Navigation */}
      <motion.nav
        className="flex-1 overflow-y-auto p-2"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.4, staggerChildren: 0.1 }}
      >
        <div className="space-y-1">
          {[
            { id: "chat" as const, icon: MessageSquare, label: "Chat" },
            { id: "code" as const, icon: Code, label: "Code" },
            { id: "image" as const, icon: ImageIcon, label: "Image" },
            { id: "history" as const, icon: History, label: "History" },
          ].map((item) => (
            <motion.button
              key={item.id}
              onClick={() => setMode(item.id)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-all ${
                mode === item.id
                  ? "bg-primary-100 text-primary-900 dark:bg-primary-900/20 dark:text-primary-300"
                  : "text-secondary-700 hover:bg-secondary-100 dark:text-secondary-300 dark:hover:bg-secondary-800"
              }`}
              variants={staggerItem}
              whileHover={{
                scale: 1.02,
                backgroundColor:
                  mode === item.id ? "" : isDarkMode ? "rgba(51, 65, 85, 0.5)" : "rgba(241, 245, 249, 0.8)",
              }}
              whileTap={{ scale: 0.98 }}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </div>
      </motion.nav>

      {/* Settings */}
      <motion.div
        className="p-4 border-t border-secondary-200 dark:border-secondary-800"
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.5 }}
      >
        <AnimatedButton variant="outline" animation="subtle" className="w-full justify-start">
          <Settings className="h-4 w-4 mr-2" />
          Settings
        </AnimatedButton>
      </motion.div>
    </motion.div>
  )

  return (
    <div className="h-screen flex flex-col md:flex-row bg-secondary-50 dark:bg-secondary-950 overflow-hidden">
      {/* Welcome animation */}
      <AnimatePresence>
        {showWelcomeAnimation && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-secondary-900"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.2, opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Logo size={100} animated={true} />
              <motion.h1
                className="mt-4 text-2xl font-bold text-white text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                Welcome to Mio AI
              </motion.h1>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Header */}
      <motion.div
        className="md:hidden flex items-center justify-between p-4 bg-white dark:bg-secondary-900 border-b border-secondary-200 dark:border-secondary-800"
        variants={fadeInDown}
        initial="hidden"
        animate="visible"
      >
        <div className="flex items-center gap-2">
          <Logo size={32} />
          <h1 className="text-xl font-bold text-secondary-900 dark:text-white">Mio AI</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(true)}>
          <Menu className="h-6 w-6" />
        </Button>
      </motion.div>

      {/* Mobile Drawer */}
      <Drawer open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <DrawerContent className="h-[90vh] p-0">
          <DrawerHeader className="border-b border-secondary-200 dark:border-secondary-800">
            <DrawerTitle>Menu</DrawerTitle>
          </DrawerHeader>
          <div className="flex-1 overflow-auto">
            <Sidebar />
          </div>
        </DrawerContent>
      </Drawer>

      {/* Desktop Sidebar */}
      <div className="hidden md:block md:w-64 h-screen">
        <Sidebar />
      </div>

      {/* Main Content */}
      <motion.div
        className="flex-1 flex flex-col h-screen md:h-auto overflow-hidden"
        variants={fadeInRight}
        initial="hidden"
        animate="visible"
      >
        {/* Mode Header */}
        <motion.header
          className="bg-white dark:bg-secondary-900 border-b border-secondary-200 dark:border-secondary-800 p-4"
          variants={fadeInDown}
          initial="hidden"
          animate="visible"
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-secondary-900 dark:text-white">
              {mode.charAt(0).toUpperCase() + mode.slice(1)} Mode
            </h2>
            {mode === "image" && imageGenerationFailed && (
              <motion.div
                className="flex items-center text-warning-500 text-sm"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
              >
                <AlertTriangle className="h-4 w-4 mr-1" />
                <span>Image generation issues</span>
              </motion.div>
            )}
          </div>
        </motion.header>

        {/* Chat Area */}
        <motion.div
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto p-4 bg-secondary-50 dark:bg-secondary-950"
          variants={fadeIn}
          initial="hidden"
          animate="visible"
          transition={{ delay: 0.3 }}
        >
          {mode === "history" ? (
            <div className="max-w-3xl mx-auto">
              <ChatHistory onSelect={loadHistory} />
            </div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-6">
              {mode === "image" && (
                <div className="max-w-3xl mx-auto w-full">
                  <ImageGeneration
                    onImageGenerated={(imageUrl, prompt) => {
                      const newMessage: Message = {
                        id: Date.now().toString(),
                        role: "assistant",
                        content: `Here's the image I generated based on your prompt: "${prompt}"`,
                        timestamp: new Date(),
                        mode: "image",
                        imageUrl: imageUrl,
                      }
                      setMessages((prev) => [...prev, newMessage])
                      lastResponseRef.current = newMessage.content
                    }}
                  />
                </div>
              )}
              <AnimatePresence initial={false}>
                {messages.map((msg, index) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{
                      type: "spring",
                      stiffness: 500,
                      damping: 30,
                      mass: 1,
                    }}
                  >
                    <ChatMessage
                      content={msg.content}
                      role={msg.role}
                      mode={msg.mode || mode}
                      onCopy={() => handleCopyMessage(msg.content)}
                      onRegenerate={msg.role === "assistant" ? () => handleRegenerate(index) : undefined}
                      imageUrl={msg.imageUrl}
                      error={msg.error}
                      fallbackUsed={msg.fallbackUsed}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>

              {isProcessing && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-center"
                >
                  <div className="bg-white dark:bg-secondary-900 rounded-lg p-6 shadow-md">
                    <AnimatedLoader
                      type={mode === "image" ? "pulse" : "dots"}
                      size="md"
                      text={mode === "image" ? "Generating image..." : "Thinking..."}
                    />
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </motion.div>

        {/* Input Area */}
        {mode !== "history" && (
          <motion.div
            className="p-4 bg-white dark:bg-secondary-900 border-t border-secondary-200 dark:border-secondary-800"
            variants={fadeInUp}
            initial="hidden"
            animate="visible"
            transition={{ delay: 0.4 }}
          >
            <form onSubmit={handleSubmit} className="max-w-3xl mx-auto">
              <div className="relative">
                <motion.div whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}>
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={(e) => {
                      setInput(e.target.value)
                      autoResizeTextarea()
                    }}
                    onKeyDown={handleKeyDown}
                    placeholder={
                      mode === "chat"
                        ? "Message Mio AI..."
                        : mode === "code"
                          ? "Describe the code you need..."
                          : "Describe the image you want to generate..."
                    }
                    className="w-full rounded-lg border border-secondary-300 dark:border-secondary-700 bg-white dark:bg-secondary-800 px-4 py-3 pr-16 text-secondary-900 dark:text-white placeholder:text-secondary-500 dark:placeholder:text-secondary-400 focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-600 resize-none min-h-[60px] max-h-[150px]"
                    disabled={isProcessing}
                    rows={1}
                  />
                </motion.div>
                <div className="absolute right-2 bottom-2 flex items-center gap-2">
                  {/* Voice Input Button */}
                  <VoiceInput
                    onSpeechResult={handleVoiceInput}
                    onSpeakToggle={handleSpeakToggle}
                    disabled={isProcessing}
                  />

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <AnimatedButton
                          type="submit"
                          disabled={isProcessing || !input.trim()}
                          animation="scale"
                          className="h-8 w-8 rounded-full bg-primary-600 hover:bg-primary-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isProcessing ? <AnimatedLoader type="spinner" size="sm" /> : <Send className="h-4 w-4" />}
                        </AnimatedButton>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Send message</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>

              <motion.div
                className="mt-2 flex items-center justify-between text-xs text-secondary-500 dark:text-secondary-400"
                variants={fadeInUp}
                initial="hidden"
                animate="visible"
                transition={{ delay: 0.5 }}
              >
                <motion.div className="flex items-center" animate={pulse}>
                  <Sparkles className="h-3 w-3 mr-1" />
                  <span>Powered by Mio AI</span>
                </motion.div>
                <div>
                  Press <kbd className="px-1 py-0.5 bg-secondary-200 dark:bg-secondary-700 rounded">Enter</kbd> to send
                  or use voice input
                </div>
              </motion.div>
            </form>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}
